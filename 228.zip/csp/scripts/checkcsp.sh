#!/bin/bash
ps -ef | grep oscam | grep -v grep > /tmp/checkoscam.log
if [ ! -s /tmp/checkoscam.log ] ; then
	/usr/local/bin/oscam -b
fi
