IrdetoPlugin
------------

Extracts irdeto ch-id from the ecm payload to help proxy card selection (used as "custom-id" in the proxy service mapping).

NOTE:
- Automatically processes all messages with caid 06xx if loaded.
- Requires CSP 0.9.0 or newer.

TODO/SUGGESTIONS:
- 

Example config:
---------------
  <plugin class="com.bowman.cardserv.IrdetoPlugin" enabled="true" jar-file="irdetoplugin.jar" />
  
Status commands:
----------------
- No commands

Usage example
-------------
- No commands
                             
