#!/bin/bash
LOG="/usr/local/csp-228/scripts/checkcsp.log"
netstat -na | grep 3500
if [ $? == 1 ] ; then
        cd /usr/local/csp-228
        echo -n "Startando CSP 3500 ... " >> $LOG
        echo `date` >> $LOG
        ./csp start
fi
